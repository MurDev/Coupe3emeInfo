<?php
session_start();

if (!empty($_SESSION['groupeA']) && !empty($_SESSION['groupeB'])) {
    $groupeA = $_SESSION['groupeA'];
    $groupeB = $_SESSION['groupeB'];
} else {
    $groupeA = ['', '', '', ''];
    $groupeB = ['', '', '', ''];
}


if (!empty($_SESSION['qualifA_df'])) {
    $qualifA_df = $_SESSION['qualifA_df'];
} else {
    $qualifA_df = ['1er Grp A', '2e Grp A'];
}

if (!empty($_SESSION['qualifB_df'])) {
    $qualifB_df = $_SESSION['qualifB_df'];
} else {
    $qualifB_df = ['1er Grp B', '2e Grp B'];
}

if (!empty($_SESSION['qualif_finale'])) {
    $qualif_finale = $_SESSION['qualif_finale'];
} else {
    $qualif_finale = ['Vainq m13', 'Vainq m14'];
}

if (!empty($_SESSION['qualif_pteFinale'])) {
    $qualif_pteFinale = $_SESSION['qualif_pteFinale'];
} else {
    $qualif_pteFinale = ['perd m13', 'perd m14'];
}




if (!empty($_SESSION['matchPlayed'][0])) {
    $m1[0] = $_SESSION['matchPlayed'][0][2];
    $m1[1] = $_SESSION['matchPlayed'][0][3];
} else {
    $m1[0] = "";
    $m1[1] = "";
}
if (!empty($_SESSION['matchPlayed'][1])) {
    $m2[0] = $_SESSION['matchPlayed'][1][2];
    $m2[1] = $_SESSION['matchPlayed'][1][3];
} else {
    $m2[0] = "";
    $m2[1] = "";
}
if (!empty($_SESSION['matchPlayed'][2])) {
    $m3[0] = $_SESSION['matchPlayed'][2][2];
    $m3[1] = $_SESSION['matchPlayed'][2][3];
} else {
    $m3[0] = "";
    $m3[1] = "";
}
if (!empty($_SESSION['matchPlayed'][3])) {
    $m4[0] = $_SESSION['matchPlayed'][3][2];
    $m4[1] = $_SESSION['matchPlayed'][3][3];
} else {
    $m4[0] = "";
    $m4[1] = "";
}
if (!empty($_SESSION['matchPlayed'][4])) {
    $m5[0] = $_SESSION['matchPlayed'][4][2];
    $m5[1] = $_SESSION['matchPlayed'][4][3];
} else {
    $m5[0] = "";
    $m5[1] = "";
}
if (!empty($_SESSION['matchPlayed'][5])) {
    $m6[0] = $_SESSION['matchPlayed'][5][2];
    $m6[1] = $_SESSION['matchPlayed'][5][3];
} else {
    $m6[0] = "";
    $m6[1] = "";
}
if (!empty($_SESSION['matchPlayed'][6])) {
    $m7[0] = $_SESSION['matchPlayed'][6][2];
    $m7[1] = $_SESSION['matchPlayed'][6][3];
} else {
    $m7[0] = "";
    $m7[1] = "";
}
if (!empty($_SESSION['matchPlayed'][7])) {
    $m8[0] = $_SESSION['matchPlayed'][7][2];
    $m8[1] = $_SESSION['matchPlayed'][7][3];
} else {
    $m8[0] = "";
    $m8[1] = "";
}
if (!empty($_SESSION['matchPlayed'][8])) {
    $m9[0] = $_SESSION['matchPlayed'][8][2];
    $m9[1] = $_SESSION['matchPlayed'][8][3];
} else {
    $m9[0] = "";
    $m9[1] = "";
}
if (!empty($_SESSION['matchPlayed'][9])) {
    $m10[0] = $_SESSION['matchPlayed'][9][2];
    $m10[1] = $_SESSION['matchPlayed'][9][3];
} else {
    $m10[0] = "";
    $m10[1] = "";
}
if (!empty($_SESSION['matchPlayed'][10])) {
    $m11[0] = $_SESSION['matchPlayed'][10][2];
    $m11[1] = $_SESSION['matchPlayed'][10][3];
} else {
    $m11[0] = "";
    $m11[1] = "";
}
if (!empty($_SESSION['matchPlayed'][11])) {
    $m12[0] = $_SESSION['matchPlayed'][11][2];
    $m12[1] = $_SESSION['matchPlayed'][11][3];
} else {
    $m12[0] = "";
    $m12[1] = "";
}
if (!empty($_SESSION['matchPlayed'][12])) {
    $m13[0] = $_SESSION['matchPlayed'][12][2];
    $m13[1] = $_SESSION['matchPlayed'][12][3];
} else {
    $m13[0] = "";
    $m13[1] = "";
}

if (!empty($_SESSION['matchPlayed'][13])) {
    $m14[0] = $_SESSION['matchPlayed'][13][2];
    $m14[1] = $_SESSION['matchPlayed'][13][3];
} else {
    $m14[0] = "";
    $m14[1] = "";
}

if (!empty($_SESSION['matchPlayed'][14])) {
    $m15[0] = $_SESSION['matchPlayed'][14][2];
    $m15[1] = $_SESSION['matchPlayed'][14][3];
} else {
    $m15[0] = "";
    $m15[1] = "";
}

if (!empty($_SESSION['matchPlayed'][15])) {
    $m16[0] = $_SESSION['matchPlayed'][15][2];
    $m16[1] = $_SESSION['matchPlayed'][15][3];

} else {
    $m16[0] = "";
    $m16[1] = "";
}

if(!empty($_SESSION['winner'])){
    $winner = $_SESSION['winner'];
}else{
    $winner = "";
}


//____________________________________________________________________________________________________
//____________________________________________________________________________________________________

//--------------GROUPE A------------------------------------------
if (!empty($_SESSION['groupe1A']))
    $_1groupeA = $_SESSION['groupe1A'];
else {
    if (!empty($_SESSION['ga']))
        $_1groupeA = [$_SESSION['ga'][0], 0, 0, 0, 0, 0, 0, 0, 0];
}

if (!empty($_SESSION['groupe2A']))
    $_2groupeA = $_SESSION['groupe2A'];
else {
    if (!empty($_SESSION['ga']))
        $_2groupeA = [$_SESSION['ga'][1], 0, 0, 0, 0, 0, 0, 0, 0];
}

if (!empty($_SESSION['groupe3A']))
    $_3groupeA = $_SESSION['groupe3A'];
else {
    if (!empty($_SESSION['ga']))
        $_3groupeA = [$_SESSION['ga'][2], 0, 0, 0, 0, 0, 0, 0, 0];
}

if (!empty($_SESSION['groupe4A']))
    $_4groupeA = $_SESSION['groupe4A'];
else {
    if (!empty($_SESSION['ga']))
        $_4groupeA = [$_SESSION['ga'][3], 0, 0, 0, 0, 0, 0, 0, 0];
}


//-------------GROUPE B---------------------------------------------
if (!empty($_SESSION['groupe1B']))
    $_1groupeB = $_SESSION['groupe1B'];
else {
    if (!empty($_SESSION['gb']))
        $_1groupeB = [$_SESSION['gb'][0], 0, 0, 0, 0, 0, 0, 0, 0];
}

if (!empty($_SESSION['groupe2B']))
    $_2groupeB = $_SESSION['groupe2B'];
else {
    if (!empty($_SESSION['gb']))
        $_2groupeB = [$_SESSION['gb'][1], 0, 0, 0, 0, 0, 0, 0, 0];
}

if (!empty($_SESSION['groupe3B']))
    $_3groupeB = $_SESSION['groupe3B'];
else {
    if (!empty($_SESSION['gb']))
        $_3groupeB = [$_SESSION['gb'][2], 0, 0, 0, 0, 0, 0, 0, 0];
}

if (!empty($_SESSION['groupe4B']))
    $_4groupeB = $_SESSION['groupe4B'];
else {
    if (!empty($_SESSION['gb']))
        $_4groupeB = [$_SESSION['gb'][3], 0, 0, 0, 0, 0, 0, 0, 0];
}

function addFlagToTeam($team)
{
    switch (strtolower($team)) {
        case 'bresil':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/brazil.svg"></span><span class="teamName">Bresil</span>';
            break;
        case 'argentine':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/argentina.svg"></span><span class="teamName">Argentine</span>';
            break;
        case 'france':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/france.svg"></span><span class="teamName">France</span>';
            break;
        case 'italie':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/italy.svg"></span><span class="teamName">Italie</span>';
            break;
        case 'espagne':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/spain.svg"></span><span class="teamName">Espagne</span>';
            break;
        case 'allemagne':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/germany.svg"></span><span class="teamName">Allemagne</span>';
            break;
        case 'portugal':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/portugal.svg"></span><span class="teamName">Portugal</span>';
            break;
        case 'haiti':
            $teamWithFlag = '<span class="imgFlag"><img src="icons/flag/haiti.svg"></span><span class="teamName">Haiti</span>';
            break;
        default:
            break;
    }
    return $teamWithFlag;
}

if (!empty($_SESSION['matchPlayed'])) {

    if (!empty($_SESSION['qualifA_df'])) {
        $qualifA_df = $_SESSION['qualifA_df'];
    } else {
        $qualifA_df = ["", ""];
    }

    if (!empty($_SESSION['qualifB_df'])) {
        $qualifB_df = $_SESSION['qualifB_df'];
    } else {
        $qualifB_df = ["", ""];
    }

    if (count($_SESSION['matchPlayed']) == 6) {
        $qualifA_df[0] = addFlagToTeam($_1groupeA[0]);
        $qualifA_df[1] = addFlagToTeam($_2groupeA[0]);

        $_SESSION['qualifA_df'] = $qualifA_df;
    }

    if (count($_SESSION['matchPlayed']) == 12) {
        $qualifB_df[0] = addFlagToTeam($_1groupeB[0]);
        $qualifB_df[1] = addFlagToTeam($_2groupeB[0]);

        $_SESSION['qualifB_df'] = $qualifB_df;
    }

    if(count($_SESSION['matchPlayed']) == 13){

        if($m13[0] > $m13[1]){
            $qualif_finale[0] = $qualifA_df[0];
            $qualif_pteFinale[0] = $qualifB_df[1];
        }
        elseif($m13[0] < $m13[1]){
            $qualif_finale[0] = $qualifB_df[1];
            $qualif_pteFinale[0] =  $qualifA_df[0];
        }
        else{
            $qualif_finale[0] = $qualifA_df[0];
            $qualif_pteFinale[0] = $qualifB_df[1];
        }

        $_SESSION['qualif_finale'] = $qualif_finale;
        $_SESSION['qualif_pteFinale'] = $qualif_pteFinale;
    }

    if(count($_SESSION['matchPlayed']) == 14){

        $qualif_finale = $_SESSION['qualif_finale'];
        $qualif_pteFinale = $_SESSION['qualif_pteFinale'];

        if($m14[0] > $m14[1]){
            $qualif_finale[1] = $qualifB_df[0];
            $qualif_pteFinale[1] = $qualifA_df[1];
        }
        elseif($m13[0] < $m13[1]){
            $qualif_finale[1] = $qualifA_df[1];
            $qualif_pteFinale[1] =  $qualifB_df[0];
        }
        else{
            $qualif_finale[1] = $qualifA_df[1];
            $qualif_pteFinale[1] =  $qualifB_df[0];
        }

        $_SESSION['qualif_finale'] = $qualif_finale;
        $_SESSION['qualif_pteFinale'] = $qualif_pteFinale;
    }

}

?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration | Coupe 3e Infos</title>
    <link rel="icon" href="icons/trophy.svg">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dark_mode.css">
    <link rel="stylesheet" href="css/tabPanes.css">
    <link rel="stylesheet" href="css/qualif.css">
</head>

<body id="mainPage">

    <!-- SIDEBAR MENU  -->
    <div class="container" id="container">
        <div class="navigation active">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><img class="icones trophy" src="icons/trophy.svg"></span>
                        <span class="title">
                            <h2>Coupe 3e</h2>
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="icon"><img class="icones" src="icons/dashboard (3).svg"></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="dashbo.php?#groupPart">
                        <span class="icon"><img class="icones" src="icons/ranking (1).svg"></span>
                        <span class="title">Groupe A & B</span>
                    </a>
                </li>
                <li>
                    <a href="dashbo.php?#resultMatch">
                        <span class="icon"><img class="icones" src="icons/scoreboard.svg"></span>
                        <span class="title">Match</span>
                    </a>
                </li>
                <li>
                    <a href="dashbo.php?#rank">
                        <span class="icon"><img class="icones" src="icons/ranking (3).svg"></span>
                        <span class="title">Classement</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="icon"><img class="icones" src="icons/dashboard (3).svg"></span>
                        <span class="title">Se deconnecter</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- FIN MENU -->

        <div class="main active">
            <div class="topbar">
                <div class="toggle" onclick="toggleMenu();">
                    <img id="menu" src="icons/list.svg" width="25" height="25">
                </div>
                <div class="bloc_icone">
                    <div class="toogle_theme" id="toggleTheme">
                        <img id="moonImg" src="icons/bx-moon.svg">
                        <img id="sunImg" src="icons/dashboard (1).svg">
                    </div>

                    <div class="user">
                        <img src="icons/profile.svg">
                    </div>
                </div>
            </div>

            <div class="cardBox">
                <div class="card" id="card_1">
                    <div>
                        <div class="numbers">0</div>
                        <div class="cardName">Match joués</div>
                    </div>
                    <div class="iconBox"></div>
                </div>
                <div class="card" id="card_2">
                    <div>
                        <div class="numbers">0</div>
                        <div class="cardName">Match Recent</div>
                    </div>
                    <div class="iconBox"></div>
                </div>
                <div class="card" id="card_3">
                    <div>
                        <div class="numbers">Lorem</div>
                        <div class="cardName">Meilleur Buteur</div>
                    </div>
                    <div class="iconBox"></div>
                </div>
                <div class="card" id="card_4">
                    <div>
                        <div class="numbers">0</div>
                        <div class="cardName">Total Buts</div>
                    </div>
                    <div class="iconBox"></div>
                </div>
            </div>

            <div class="lot">
                <div class="equipeParLots">
                    <div class="cardHeader">
                        <h3>LOT</h3>
                    </div>
                    <form action="proc.php" method="POST">
                        <table>
                            <thead>
                                <tr>
                                    <td>Lot #1</td>
                                    <td>Lot #2</td>
                                    <td>Lot #3</td>
                                    <td>Lot #4</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/brazil.svg"></span>
                                            <span class="teamName">Brésil</span>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/france.svg"></span>
                                            <span class="teamName">France</span>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/spain.svg"></span>
                                            <span class="teamName">Espagne</span>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/portugal.svg"></span>
                                            <span class="teamName">Portugal</span>
                                        </span>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/argentina.svg"></span>
                                            <span class="teamName">Argentine</span>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/italy.svg"></span>
                                            <span class="teamName">Italie</span>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/germany.svg"></span>
                                            <span class="teamName">Allemagne</span>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="bloc_teamFlag">
                                            <span class="imgFlag"><img src="icons/flag/haiti.svg"></span>
                                            <span class="teamName">Haiti</span>
                                        </span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <button type="submit" name="tirage" id="btn-tirage">Effectuer un tirage</button>
                    </form>
                </div>
            </div>


            <?php if (!empty($_SESSION['groupeA']) && !empty($_SESSION['groupeB'])) : ?>

                <div id="groupPart" class="groupBox">
                    <div id="resultTirage" class="compo">
                        <div class="cardHeader">
                            <h3>Compositions des groupes</h3>
                        </div>
                        <table>
                            <thead>
                                <th>Groupe A</th>
                                <th>Groupe B</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <span id="eq1" class="bloc_teamFlag">
                                            <?= $groupeA[0] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span id="eq2" class="bloc_teamFlag">
                                            <?= $groupeB[0] ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span id="eq3" class="bloc_teamFlag">
                                            <?= $groupeA[1] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span id="eq4" class="bloc_teamFlag">
                                            <?= $groupeB[1] ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span id="eq5" class="bloc_teamFlag">
                                            <?= $groupeA[2] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span id="eq6" class="bloc_teamFlag">
                                            <?= $groupeB[2] ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span id="eq7" class="bloc_teamFlag">
                                            <?= $groupeA[3] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span id="eq8" class="bloc_teamFlag">
                                            <?= $groupeB[3] ?>
                                        </span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <script>
                    document.getElementById("eq1").classList.add("shw1");
                    document.getElementById("eq2").classList.add("shw2");
                    document.getElementById("eq3").classList.add("shw3");
                    document.getElementById("eq4").classList.add("shw4");
                    document.getElementById("eq5").classList.add("shw5");
                    document.getElementById("eq6").classList.add("shw6");
                    document.getElementById("eq7").classList.add("shw7");
                    document.getElementById("eq8").classList.add("shw8");
                </script>

                <div class="tabs">

                    <div class="tab-header">
                        <div id="resultMatch" class="active">Match</div>
                        <div id="rank">Classement</div>
                        <div>Qualifications</div>
                        <div>Statistiques</div>
                    </div>

                    <div class="tab-content">
                        <div class="active">
                            <div class="matchBox">
                                <div class="matchGroupA">
                                    <div class="cardHeader">
                                        <h3>Match</h3> 1er tour
                                    </div>

                                    <div id="div_groupA_in_matchGroupA">
                                        <h5>Groupe A</h5>
                                    </div>

                                    <table>
                                        <thead>
                                            <th># match</th>
                                            <th>equipe 1</th>
                                            <th >resultat</th>
                                            <th>equipe 2</th>
                                            <th>date</th>
                                            <th>stade</th>
                                            <th>action</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><span id="matchID_matchOne">1</span></td>
                                                <td><span id="team1_matchOne" class="reverse_flag"><?= $groupeA[0] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m1[0]; ?>-<?= $m1[1]; ?></span></td>
                                                <td><span id="team2_matchOne" class="bloc_teamFlag"><?= $groupeA[1] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchOne"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchTwo">2</span></td>
                                                <td><span id="team1_matchTwo" class="reverse_flag"><?= $groupeA[2] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m2[0]; ?>-<?= $m2[1]; ?></span></td>
                                                <td><span id="team2_matchTwo" class="bloc_teamFlag"><?= $groupeA[3] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchTwo"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchThree">3</span></td>
                                                <td><span id="team1_matchThree" class="reverse_flag"><?= $groupeA[0] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m3[0]; ?>-<?= $m3[1]; ?></span></td>
                                                <td><span id="team2_matchThree" class="bloc_teamFlag"><?= $groupeA[2] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchThree"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchFour">4</span></td>
                                                <td><span id="team1_matchFour" class="reverse_flag"><?= $groupeA[1] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m4[0]; ?>-<?= $m4[1]; ?></span></td>
                                                <td><span id="team2_matchFour" class="bloc_teamFlag"><?= $groupeA[3] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchFour"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchFive">5</span></td>
                                                <td><span id="team1_matchFive" class="reverse_flag"><?= $groupeA[0] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m5[0]; ?>-<?= $m5[1]; ?></span></td>
                                                <td><span id="team2_matchFive" class="bloc_teamFlag"><?= $groupeA[3] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchFive"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchSix">6</span></td>
                                                <td><span id="team1_matchSix" class="reverse_flag"><?= $groupeA[1] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m6[0]; ?>-<?= $m6[1]; ?></span></td>
                                                <td><span id="team2_matchSix" class="bloc_teamFlag"><?= $groupeA[2] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span></td>
                                                <td id="matchSix"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div id="div_groupA_in_matchGroupB">
                                        <h5>Groupe B</h5>
                                    </div>

                                    <table class="table_matchB">
                                        <thead>
                                            <th># match</th>
                                            <th>equipe 1</th>
                                            <th>resultat</th>
                                            <th>equipe 2</th>
                                            <th>date</th>
                                            <th>stade</th>
                                            <th>action</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><span id="matchID_matchSeven">7</span></td>
                                                <td><span id="team1_matchSeven" class="reverse_flag"><?= $groupeB[0] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m7[0]; ?>-<?= $m7[1]; ?></span></td>
                                                <td><span id="team2_matchSeven" class="bloc_teamFlag"><?= $groupeB[1] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchSeven"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchHeight">8</span></td>
                                                <td><span id="team1_matchHeight" class="reverse_flag"><?= $groupeB[2] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m8[0]; ?>-<?= $m8[1]; ?></span></td>
                                                <td><span id="team2_matchHeight" class="bloc_teamFlag"><?= $groupeB[3] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchHeight"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchNine">9</span></td>
                                                <td><span id="team1_matchNine" class="reverse_flag"><?= $groupeB[0] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m9[0]; ?>-<?= $m9[1]; ?></span></td>
                                                <td><span id="team2_matchNine" class="bloc_teamFlag"><?= $groupeB[2] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchNine"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchTen">10</span></td>
                                                <td><span id="team1_matchTen" class="reverse_flag"><?= $groupeB[1] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m10[0]; ?>-<?= $m10[1]; ?></span></td>
                                                <td><span id="team2_matchTen" class="bloc_teamFlag"><?= $groupeB[3] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchTen"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchEleven">11</span></td>
                                                <td><span id="team1_matchEleven" class="reverse_flag"><?= $groupeB[0] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m11[0]; ?>-<?= $m11[1]; ?></span></td>
                                                <td><span id="team2_matchEleven" class="bloc_teamFlag"><?= $groupeB[3] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchEleven"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>

                                            <tr>
                                                <td><span id="matchID_matchTwelve">12</span></td>
                                                <td><span id="team1_matchTwelve" class="reverse_flag"><?= $groupeB[1] ?></span></td>
                                                <td class="score_cell"><span class="case_score"><?= $m12[0]; ?>-<?= $m12[1]; ?></span></td>
                                                <td><span id="team2_matchTwelve" class="bloc_teamFlag"><?= $groupeB[2] ?></span></td>
                                                <td>04-oct-2021</td>
                                                <td><span class="bloc_teamFlag"><span class="imgFlag"><img src="icons/stadium.svg"></span><span class="teamName">Inuka stadium</span></td>
                                                <td id="matchTwelve"><button class="btn_set_score">Entrez le score</button></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div>
                            <div class="rankingBox">
                                <div class="rankGroup">
                                    <div class="cardHeader">
                                        <h3>CLASSEMENT</h3>
                                    </div>
                                    <div id="div_groupA_in_matchGroupA">
                                        <h5>Groupe A</h5>
                                    </div>

                                    <table>
                                        <thead>
                                            <th><span class="not_qualifying_dot">#</span></th>
                                            <th>Equipe</th>
                                            <th>MJ</th>
                                            <th>MG</th>
                                            <th>MN</th>
                                            <th>MP</th>
                                            <th>BP</th>
                                            <th>BC</th>
                                            <th>Dif</th>
                                            <th>Pts</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><span class="qualifying_dot">1</span></td>
                                                <td><?= $_1groupeA[0] ?></td>
                                                <td><?= $_1groupeA[1] ?></td>
                                                <td><?= $_1groupeA[2] ?></td>
                                                <td><?= $_1groupeA[3] ?></td>
                                                <td><?= $_1groupeA[4] ?></td>
                                                <td><?= $_1groupeA[5] ?></td>
                                                <td><?= $_1groupeA[6] ?></td>
                                                <td><?= $_1groupeA[7] ?></td>
                                                <td><?= $_1groupeA[8] ?></td>
                                            </tr>

                                            <tr>
                                                <td><span class="qualifying_dot">2</span></td>
                                                <td><?= $_2groupeA[0] ?></td>
                                                <td><?= $_2groupeA[1] ?></td>
                                                <td><?= $_2groupeA[2] ?></td>
                                                <td><?= $_2groupeA[3] ?></td>
                                                <td><?= $_2groupeA[4] ?></td>
                                                <td><?= $_2groupeA[5] ?></td>
                                                <td><?= $_2groupeA[6] ?></td>
                                                <td><?= $_2groupeA[7] ?></td>
                                                <td><?= $_2groupeA[8] ?></td>
                                            </tr>

                                            <tr>
                                                <td><span class="not_qualifying_dot">3</span></td>
                                                <td><?= $_3groupeA[0] ?></td>
                                                <td><?= $_3groupeA[1] ?></td>
                                                <td><?= $_3groupeA[2] ?></td>
                                                <td><?= $_3groupeA[3] ?></td>
                                                <td><?= $_3groupeA[4] ?></td>
                                                <td><?= $_3groupeA[5] ?></td>
                                                <td><?= $_3groupeA[6] ?></td>
                                                <td><?= $_3groupeA[7] ?></td>
                                                <td><?= $_3groupeA[8] ?></td>
                                            </tr>

                                            <tr>
                                                <td><span class="not_qualifying_dot">4</span></td>
                                                <td><?= $_4groupeA[0] ?></td>
                                                <td><?= $_4groupeA[1] ?></td>
                                                <td><?= $_4groupeA[2] ?></td>
                                                <td><?= $_4groupeA[3] ?></td>
                                                <td><?= $_4groupeA[4] ?></td>
                                                <td><?= $_4groupeA[5] ?></td>
                                                <td><?= $_4groupeA[6] ?></td>
                                                <td><?= $_4groupeA[7] ?></td>
                                                <td><?= $_4groupeA[8] ?></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div id="div_groupA_in_matchGroupB">
                                        <h5>Groupe B</h5>
                                    </div>

                                    <table>
                                        <thead>
                                            <th><span class="not_qualifying_dot">#</span></th>
                                            <th>Equipe</th>
                                            <th>MJ</th>
                                            <th>MG</th>
                                            <th>MN</th>
                                            <th>MP</th>
                                            <th>BP</th>
                                            <th>BC</th>
                                            <th>Dif</th>
                                            <th>Pts</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><span class="qualifying_dot">1</span></td>
                                                <td><?= $_1groupeB[0] ?></td>
                                                <td><?= $_1groupeB[1] ?></td>
                                                <td><?= $_1groupeB[2] ?></td>
                                                <td><?= $_1groupeB[3] ?></td>
                                                <td><?= $_1groupeB[4] ?></td>
                                                <td><?= $_1groupeB[5] ?></td>
                                                <td><?= $_1groupeB[6] ?></td>
                                                <td><?= $_1groupeB[7] ?></td>
                                                <td><?= $_1groupeB[8] ?></td>
                                            </tr>

                                            <tr>
                                                <td><span class="qualifying_dot">2</span></td>
                                                <td><?= $_2groupeB[0] ?></td>
                                                <td><?= $_2groupeB[1] ?></td>
                                                <td><?= $_2groupeB[2] ?></td>
                                                <td><?= $_2groupeB[3] ?></td>
                                                <td><?= $_2groupeB[4] ?></td>
                                                <td><?= $_2groupeB[5] ?></td>
                                                <td><?= $_2groupeB[6] ?></td>
                                                <td><?= $_2groupeB[7] ?></td>
                                                <td><?= $_2groupeB[8] ?></td>
                                            </tr>

                                            <tr>
                                                <td><span class="not_qualifying_dot">3</span></td>
                                                <td><?= $_3groupeB[0] ?></td>
                                                <td><?= $_3groupeB[1] ?></td>
                                                <td><?= $_3groupeB[2] ?></td>
                                                <td><?= $_3groupeB[3] ?></td>
                                                <td><?= $_3groupeB[4] ?></td>
                                                <td><?= $_3groupeB[5] ?></td>
                                                <td><?= $_3groupeB[6] ?></td>
                                                <td><?= $_3groupeB[7] ?></td>
                                                <td><?= $_3groupeB[8] ?></td>
                                            </tr>

                                            <tr>
                                                <td><span class="not_qualifying_dot">4</span></td>
                                                <td><?= $_4groupeB[0] ?></td>
                                                <td><?= $_4groupeB[1] ?></td>
                                                <td><?= $_4groupeB[2] ?></td>
                                                <td><?= $_4groupeB[3] ?></td>
                                                <td><?= $_4groupeB[4] ?></td>
                                                <td><?= $_4groupeB[5] ?></td>
                                                <td><?= $_4groupeB[6] ?></td>
                                                <td><?= $_4groupeB[7] ?></td>
                                                <td><?= $_4groupeB[8] ?></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div class="notice">
                                        Notice : Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sint aliquid obcaecati ipsa consectetur facere nihil ratione itaque laborum reprehenderit doloribus. Harum impedit sapiente tenetur dignissimos consequatur culpa accusamus placeat odio?
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <div id="matchQualif" class="qualifBox">
                                <div class="qualifMatch">
                                    <div class="container">
                                        <div class="container_bloc_match">
                                            <div class="bloc_match">
                                                <div class="match_df">
                                                    <div class="heure_df"><span id="matchID_matchThirteen">13</span> 09 oct 21 - 12:00</div>
                                                    <div class="box_teamScore">
                                                        <table class="table_df">
                                                            <tr>
                                                                <td>
                                                                    <span id="team1_matchThirteen" class="reverse_flag"><?= $qualifA_df[0] ?></span>
                                                                </td>
                                                                <td><span><?= $m13[0] ?> - <?= $m13[1] ?></span></td>
                                                                <td>
                                                                    <span id="team2_matchThirteen" class="bloc_teamFlag"><?= $qualifB_df[1] ?></span>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div id="matchThirteen" class="qlfBtn">
                                                        <button class="btn_set_score">Entrez le score</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="bloc_match">
                                                <div class="match_df">
                                                    <div class="heure_df"><span id="matchID_matchFourteen">14</span> 09 oct 21 - 12:00</div>
                                                    <div class="box_teamScore">
                                                        <table class="table_df">
                                                            <tr>
                                                                <td>
                                                                    <span id="team1_matchFourteen" class="reverse_flag"><?= $qualifB_df[0] ?></span>
                                                                </td>
                                                                <td><span><?= $m14[0] ?> - <?= $m14[1] ?></span></td>
                                                                <td>
                                                                    <span id="team2_matchFourteen" class="bloc_teamFlag"><?= $qualifA_df[1] ?></span>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div id="matchFourteen" class="qlfBtn">
                                                        <button class="btn_set_score">Entrez le score</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="container_bloc_match2">
                                            <div class="bloc_invisible">

                                            </div>
                                            <div class="bracket">
                                            </div>
                                            <div class="bracket2_match2">
                                            </div>
                                            <div class="bracket3_match2">
                                            </div>
                                        </div>
                                        <div class="container_bloc_match3">
                                            <div class="bloc_invisible2">

                                            </div>
                                            <div class="bracket2 borBracket1">
                                            </div>
                                            <div class="bracket2 borBracket2">
                                            </div>
                                        </div>
                                        <div class="container_bloc_match4">
                                            <div class="bloc_match">
                                                <div class="match_df">
                                                    <div class="heure_df"><span id="matchID_matchSixteen">16</span> 09 oct 21 - 12:00</div>
                                                    <div class="box_teamScore">
                                                        <table class="table_df">
                                                            <tr>
                                                                <td>
                                                                    <span id="team1_matchSixteen" class="reverse_flag"><?= $qualif_finale[0] ?></span>
                                                                </td>
                                                                <td><span><?= $m16[0] ?> - <?= $m16[1] ?> </span></td>
                                                                <td>
                                                                    <span id="team2_matchSixteen" class="bloc_teamFlag"><?= $qualif_finale[1] ?></span>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div id="matchSixteen" class="qlfBtn">
                                                        <button class="btn_set_score">Entrez le score</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="container_bloc_match5">
                                            <div class="bloc_match">
                                                <div class="trophyFinal">
                                                <span class="winner"><?= $winner ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="qualifMatch">
                                    <div class="container">
                                        <div class="container_bloc_match4">
                                            
                                        </div>

                                        <div class="container_bloc_match4">
                                            <div class="bloc_match">
                                                <div class="match_df">
                                                    <div class="heure_df"><span id="matchID_matchFifteen">15</span> 09 oct 21 - 12:00</div>
                                                    <div class="box_teamScore">
                                                        <table class="table_df">
                                                            <tr>
                                                                <td>
                                                                    <span id="team1_matchFifteen" class="reverse_flag"><?= $qualif_pteFinale[0] ?> </span>
                                                                </td>
                                                                <td><span><?= $m15[0] ?> - <?= $m15[1] ?></span></td>
                                                                <td>
                                                                    <span id="team2_matchFifteen" class="bloc_teamFlag"><?= $qualif_pteFinale[1] ?></span>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div id="matchFifteen" class="qlfBtn">
                                                        <button class="btn_set_score">Entrez le score</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="container_bloc_match5">
                                            <div class="bloc_match">
                                                <div class="trophyLilFinal">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div>

                        </div>

                    </div>
                </div>
            <?php endif ?>

            <div id="set_score_modal">
                <div id="modal_content">
                    <div id="modal_header">
                        <span id="close">&times;</span>
                    </div>
                    <form method="POST" action="proc.php">
                        <div id="modal_body">
                            <span id="matchIdModal">Match </span>
                            <input type="hidden" id="matchNum" name="matchIdModal" value="">
                            <div class="box_team_score">
                                <div class="team team1">
                                    <span class="flagTeam1"></span>
                                    <span class="nameTeam1">Bresil</span>
                                    <input type="hidden" id="team1Modal" name="team1Modal" value="">
                                </div>

                                <div class="team score_team1">
                                    <span class="score">
                                        <select name="scoreT1">
                                            <option>0</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                        </select>
                                    </span>
                                </div>
                                <div class="tiret">
                                    <span>-</span>
                                </div>
                                <div class="team score_team2">
                                    <span class="score">
                                        <select name="scoreT2">
                                            <option>0</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>7</option>
                                            <option>8</option>
                                        </select>
                                    </span>
                                </div>

                                <div class="team team2">
                                    <span class="flagTeam2"></span>
                                    <span class="nameTeam2">Argentine</span>
                                    <input type="hidden" id="team2Modal" name="team2Modal" value="">
                                </div>
                            </div>

                            <div class="box_scorer">

                            </div>
                            <div class="box_btn">
                                <button type="submit" name="set_score">Valider</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

    <script type="text/javascript">
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active');
            main.classList.toggle('active');
        }

        var toggleTheme = document.getElementById("toggleTheme");
        var container = document.getElementById("container");
        toggleTheme.onclick = function() {
            container.classList.toggle('dark');
            var moonImg = document.getElementById('moonImg');
            var sunImg = document.getElementById('sunImg');
        }

        let tabs = document.querySelector(".tabs");
        let tabHeader = tabs.querySelector(".tab-header");
        let tabHeaderNodes = tabs.querySelectorAll(".tab-header > div");
        let tabContent = tabs.querySelector(".tab-content");
        let tabContentNodes = tabs.querySelectorAll(".tab-content > div");

        for (let i = 0; i < tabHeaderNodes.length; i++) {
            tabHeaderNodes[i].addEventListener("click", function() {
                tabHeader.querySelector(".active").classList.remove("active");
                tabHeaderNodes[i].classList.add("active");
                tabContent.querySelector(".active").classList.remove("active");
                tabContentNodes[i].classList.add("active");
            });
        }

        var setscore = document.querySelectorAll(".btn_set_score");
        let closeModal = document.getElementById("close");
        var modal = document.getElementById('set_score_modal');

        setscore.forEach(selF => {
            selF.addEventListener('click', function() {
                modal.style.display = 'block';

                var parenId = this.parentNode.id;

                let matchID = document.getElementById("matchID_" + parenId).textContent;
                let matchIdModal = document.getElementById("matchIdModal");

                let team1 = document.getElementById("team1_" + parenId).textContent;
                let team2 = document.getElementById("team2_" + parenId).textContent;

                let nameTeam1_Modal = document.querySelector(".nameTeam1");
                let nameTeam2_Modal = document.querySelector(".nameTeam2");

                let flagTeam1_Modal = document.querySelector(".flagTeam1");
                let flagTeam2_Modal = document.querySelector(".flagTeam2");

                switch (team1) {
                    case "Bresil":
                        flagTeam1_Modal.classList.add('brazilFlag');
                        break;
                    case "Argentine":
                        flagTeam1_Modal.classList.add('argentinaFlag');
                        break;
                    case "France":
                        flagTeam1_Modal.classList.add('frenchFlag');
                        break;
                    case "Italie":
                        flagTeam1_Modal.classList.add('italiaFlag');
                        break;
                    case "Espagne":
                        flagTeam1_Modal.classList.add('spainFlag');
                        break;
                    case "Allemagne":
                        flagTeam1_Modal.classList.add('germanyFlag');
                        break;
                    case "Portugal":
                        flagTeam1_Modal.classList.add('portugalFlag');
                        break;
                    case "Haiti":
                        flagTeam1_Modal.classList.add('haitiFlag');
                        break;
                    default:
                        break;
                }

                switch (team2) {
                    case "Bresil":
                        flagTeam2_Modal.classList.add('brazilFlag');
                        break;
                    case "Argentine":
                        flagTeam2_Modal.classList.add('argentinaFlag');
                        break;
                    case "France":
                        flagTeam2_Modal.classList.add('frenchFlag');
                        break;
                    case "Italie":
                        flagTeam2_Modal.classList.add('italiaFlag');
                        break;
                    case "Espagne":
                        flagTeam2_Modal.classList.add('spainFlag');
                        break;
                    case "Allemagne":
                        flagTeam2_Modal.classList.add('germanyFlag');
                        break;
                    case "Portugal":
                        flagTeam2_Modal.classList.add('portugalFlag');
                        break;
                    case "Haiti":
                        flagTeam2_Modal.classList.add('haitiFlag');
                        break;
                    default:
                        break;
                }

                console.log("id parent : " + parenId);
                console.log("Equipe 1 : " + team1);

                matchIdModal.textContent = "Match " + matchID;
                document.getElementById("team1Modal").value = team1;
                document.getElementById("team2Modal").value = team2;
                document.getElementById("matchNum").value = matchID;
                nameTeam1_Modal.textContent = team1;
                nameTeam2_Modal.textContent = team2;
            });

        });

        closeModal.onclick = function() {
            var activateModal = document.getElementById('set_score_modal');
            modal.style.display = 'none';
            document.querySelector(".flagTeam1").classList.remove('brazilFlag');
            document.querySelector(".flagTeam1").classList.remove('argentinaFlag');
            document.querySelector(".flagTeam1").classList.remove('germanyFlag');
            document.querySelector(".flagTeam1").classList.remove('frenchFlag');
            document.querySelector(".flagTeam1").classList.remove('italiaFlag');
            document.querySelector(".flagTeam1").classList.remove('spainFlag');
            document.querySelector(".flagTeam1").classList.remove('portugalFlag');
            document.querySelector(".flagTeam1").classList.remove('haitiFlag');

            document.querySelector(".flagTeam2").classList.remove('brazilFlag');
            document.querySelector(".flagTeam2").classList.remove('argentinaFlag');
            document.querySelector(".flagTeam2").classList.remove('germanyFlag');
            document.querySelector(".flagTeam2").classList.remove('frenchFlag');
            document.querySelector(".flagTeam2").classList.remove('italiaFlag');
            document.querySelector(".flagTeam2").classList.remove('spainFlag');
            document.querySelector(".flagTeam2").classList.remove('portugalFlag');
            document.querySelector(".flagTeam2").classList.remove('haitiFlag');
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

</body>

</html>