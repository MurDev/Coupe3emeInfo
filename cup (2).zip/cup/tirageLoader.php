<div class="main-loader">
    <img src="images/tirageLoader.gif">
</div>

<style type="text/css">
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    html,
    body {
        margin: 0;
        padding: 0;
    }

    .main-loader {
        width: 100%;
        min-height: 100vh;
        background-color: hsla(232, 23%, 41%, 1);
    }

    .main-loader img {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        max-width: 100%;
        max-height: 100%;
    }
</style>