<?php
// require 'functions/authentification.php';
// connect_user();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil - Coupe 3e</title>
</head>

<body>
    <?php
        header('refresh:2; url=dashbo.php');
    ?>

    <div id="preloader">
        <?php include 'preloader.php' ?>
    </div>





    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        #preloader {
            width: 100%;
            height: 100vh;
            background-color: #000;
        }
    </style>

    <script>
        function disappear_preloader() {
            var preloader = document.getElementById("preloader");
            preloader.style.display = "none";
        }

        window.addEventListener("load", function() {
            setInterval(disappear_preloader, 1000);
        });
    </script>
</body>

</html>