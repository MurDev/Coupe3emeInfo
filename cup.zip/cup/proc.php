<?php
session_start();
/* -----------DECLARATION VARIABLE---------------*/

$listeEquipe = [
    '<span class="imgFlag"><img src="icons/flag/brazil.svg"></span><span class="teamName">Bresil</span>',
    '<span class="imgFlag"><img src="icons/flag/argentina.svg"></span><span class="teamName">Argentine</span>',
    '<span class="imgFlag"><img src="icons/flag/france.svg"></span><span class="teamName">France</span>',
    '<span class="imgFlag"><img src="icons/flag/italy.svg"></span><span class="teamName">Italie</span>',
    '<span class="imgFlag"><img src="icons/flag/spain.svg"></span><span class="teamName">Espagne</span>',
    '<span class="imgFlag"><img src="icons/flag/germany.svg"></span><span class="teamName">Allemagne</span>',
    '<span class="imgFlag"><img src="icons/flag/portugal.svg"></span><span class="teamName">Portugal</span>',
    '<span class="imgFlag"><img src="icons/flag/haiti.svg"></span><span class="teamName">Haiti</span>'
];

$ls = ['Bresil', 'Argentine', 'France', 'Italie', 'Espagne', 'Allemagne', 'Portugal', 'Haiti'];
$ga = [];
$gb = [];

$groupeA = [];
$groupeB = [];

/* ------------------------------------------------------ */

/* ------------Traitement ------------------------------- */

// ____________________TIRAGE__________________________  //
if (isset($_POST['tirage'])) {
    include 'tirageLoader.php';
    for ($i = 0; $i <= 7; $i = $i + 2) {
        $result = rand(0, 1);

        if ($result % 2 == 0) {
            array_push($groupeA, $listeEquipe[$i]);
            array_push($groupeB, $listeEquipe[$i + 1]);
            array_push($ga, $ls[$i]);
            array_push($gb, $ls[$i + 1]);
        } else {
            array_push($groupeA, $listeEquipe[$i + 1]);
            array_push($groupeB, $listeEquipe[$i]);
            array_push($ga, $ls[$i + 1]);
            array_push($gb, $ls[$i]);
        }
    }

    $_SESSION['groupeA'] = $groupeA;
    $_SESSION['groupeB'] = $groupeB;

    $_SESSION['ga'] = $ga;
    $_SESSION['gb'] = $gb;

    header('refresh:3.4; url=dashbo.php?#resultTirage');
}
//_______________________________________________________________________

//_____________________FUNCTIONS_________________________________________

function win($teamName, $tab, $butMarque, $butEncaisse)
{
    $tab[0] = $teamName;
    $tab[1] = $tab[1] + 1;
    $tab[2] = $tab[2] + 1;
    $tab[3] = $tab[3] + 0;
    $tab[4] = $tab[4] + 0;
    $tab[5] = $tab[5] + $butMarque;
    $tab[6] = $tab[6] + $butEncaisse;
    $tab[7] = $tab[5] - $tab[6];
    $tab[8] = $tab[8] + 3;

    return $tab;
}

function lost($teamName, $tab, $butMarque, $butEncaisse)
{
    $tab[0] = $teamName;
    $tab[1] = $tab[1] + 1;
    $tab[2] = $tab[2] + 0;
    $tab[3] = $tab[3] + 0;
    $tab[4] = $tab[4] + 1;
    $tab[5] = $tab[5] + $butMarque;
    $tab[6] = $tab[6] + $butEncaisse;
    $tab[7] = $tab[5] - $tab[6];
    $tab[8] = $tab[8] + 0;

    return $tab;
}

function draw($teamName, $tab, $butMarque, $butEncaisse)
{
    $tab[0] = $teamName;
    $tab[1] = $tab[1] + 1;
    $tab[2] = $tab[2] + 0;
    $tab[3] = $tab[3] + 1;
    $tab[4] = $tab[4] + 0;
    $tab[5] = $tab[5] + $butMarque;
    $tab[6] = $tab[6] + $butEncaisse;
    $tab[7] = $tab[5] - $tab[6];
    $tab[8] = $tab[8] + 1;

    return $tab;
}

function setMatch($team1, $team2, $s1, $s2, $tabTeam1, $tabTeam2)
{
    $scoreTeam1 = intval($s1);
    $scoreTeam2 = intval($s2);

    if ($scoreTeam1 > $scoreTeam2) {
        $tabTeam1 = win($team1, $tabTeam1, $scoreTeam1, $scoreTeam2);
        $tabTeam2 = lost($team2, $tabTeam2, $scoreTeam2, $scoreTeam1);
    } else if ($scoreTeam2 > $scoreTeam1) {
        $tabTeam2 = win($team2, $tabTeam2, $scoreTeam2, $scoreTeam1);
        $tabTeam1 = lost($team1, $tabTeam1, $scoreTeam1, $scoreTeam2);
    } else {
        $tabTeam1 = draw($team1, $tabTeam1, $scoreTeam1, $scoreTeam2);
        $tabTeam2 = draw($team2, $tabTeam2, $scoreTeam2, $scoreTeam1);
    }

    $_SESSION[strtolower($team1)] =  $tabTeam1;
    $_SESSION[strtolower($team2)] =  $tabTeam2;
}

//_______________________________________________________________________

$matchPlayed = [];

if (!empty($_SESSION['matchPlayed'][0])) {
    $matchPlayed[0] = $_SESSION['matchPlayed'][0];
}
if (!empty($_SESSION['matchPlayed'][1])) {
    $matchPlayed[1] = $_SESSION['matchPlayed'][1];
}
if (!empty($_SESSION['matchPlayed'][2])) {
    $matchPlayed[2] = $_SESSION['matchPlayed'][2];
}
if (!empty($_SESSION['matchPlayed'][3])) {
    $matchPlayed[3] = $_SESSION['matchPlayed'][3];
}
if (!empty($_SESSION['matchPlayed'][4])) {
    $matchPlayed[4] = $_SESSION['matchPlayed'][4];
}
if (!empty($_SESSION['matchPlayed'][5])) {
    $matchPlayed[5] = $_SESSION['matchPlayed'][5];
}
if (!empty($_SESSION['matchPlayed'][6])) {
    $matchPlayed[6] = $_SESSION['matchPlayed'][6];
}
if (!empty($_SESSION['matchPlayed'][7])) {
    $matchPlayed[7] = $_SESSION['matchPlayed'][7];
}
if (!empty($_SESSION['matchPlayed'][8])) {
    $matchPlayed[8] = $_SESSION['matchPlayed'][8];
}
if (!empty($_SESSION['matchPlayed'][9])) {
    $matchPlayed[9] = $_SESSION['matchPlayed'][9];
}
if (!empty($_SESSION['matchPlayed'][10])) {
    $matchPlayed[10] = $_SESSION['matchPlayed'][10];
}
if (!empty($_SESSION['matchPlayed'][11])) {
    $matchPlayed[11] = $_SESSION['matchPlayed'][11];
}
if (!empty($_SESSION['matchPlayed'][12])) {
    $matchPlayed[12] = $_SESSION['matchPlayed'][12];
}
if (!empty($_SESSION['matchPlayed'][13])) {
    $matchPlayed[13] = $_SESSION['matchPlayed'][13];
}
if (!empty($_SESSION['matchPlayed'][14])) {
    $matchPlayed[14] = $_SESSION['matchPlayed'][14];
}
if (!empty($_SESSION['matchPlayed'][15])) {
    $matchPlayed[15] = $_SESSION['matchPlayed'][15];
}

//GESTION CLASSSEMENT

// RECUPERER TABLEAU
if (empty($_SESSION['bresil']))
    $_SESSION['bresil'] = $bresil = ["Bresil", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $bresil = $_SESSION['bresil'];

if (empty($_SESSION['argentine']))
    $_SESSION['argentine'] = $argentine = ["Argentine", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $argentine = $_SESSION['argentine'];

if (empty($_SESSION['france']))
    $_SESSION['france'] = $france = ["France", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $france = $_SESSION['france'];

if (empty($_SESSION['italie']))
    $_SESSION['italie'] = $italie = ["Italie", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $italie = $_SESSION['italie'];

if (empty($_SESSION['espagne']))
    $_SESSION['espagne'] = $espagne = ["Espagne", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $espagne = $_SESSION['espagne'];

if (empty($_SESSION['allemagne']))
    $_SESSION['allemagne'] = $allemagne = ["Allemagne", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $allemagne = $_SESSION['allemagne'];

if (empty($_SESSION['portugal']))
    $_SESSION['portugal'] = $portugal = ["Portugal", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $portugal = $_SESSION['portugal'];

if (empty($_SESSION['haiti']))
    $_SESSION['haiti'] = $haiti = ["Haiti", 0, 0, 0, 0, 0, 0, 0, 0];
else
    $haiti = $_SESSION['haiti'];


if (isset($_POST['set_score'])) {
    echo "<br>MatchID : " . $_POST['matchIdModal'];
    switch ($_POST['matchIdModal']) {
        case '1':
            $matchPlayed[0] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '2':
            $matchPlayed[1] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '3':
            $matchPlayed[2] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '4':
            $matchPlayed[3] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '5':
            $matchPlayed[4] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '6':
            $matchPlayed[5] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '7':
            $matchPlayed[6] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '8':
            $matchPlayed[7] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '9':
            $matchPlayed[8] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '10':
            $matchPlayed[9] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '11':
            $matchPlayed[10] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '12':
            $matchPlayed[11] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            $team1 = strtolower($_POST['team1Modal']);
            $team2 = strtolower($_POST['team2Modal']);
            setMatch($_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2'], ${$team1}, ${$team2});

            break;
        case '13':
            $matchPlayed[12] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;

            break;
        case '14':
            $matchPlayed[13] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;
            break;
        case '15':
            $matchPlayed[14] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            $_SESSION['matchPlayed'] = $matchPlayed;
            break;
        case '16':
            $matchPlayed[15] = [$_POST['team1Modal'], $_POST['team2Modal'], $_POST['scoreT1'], $_POST['scoreT2']];
            if($_POST['scoreT1'] > $_POST['scoreT2']){
                $_SESSION['winner'] = $_POST['team1Modal'];
            }elseif($_POST['scoreT1'] < $_POST['scoreT2']){
                $_SESSION['winner'] = $_POST['team2Modal'];
            }
            else{
                $_SESSION['winner'] = $_POST['team1Modal'];
            }
            $_SESSION['matchPlayed'] = $matchPlayed;
            break;
        default:
            break;
    }

    $_1ga = strtolower($_SESSION['ga'][0]);
    $_2ga = strtolower($_SESSION['ga'][1]);
    $_3ga = strtolower($_SESSION['ga'][2]);
    $_4ga = strtolower($_SESSION['ga'][3]);

    $_1gb = strtolower($_SESSION['gb'][0]);
    $_2gb = strtolower($_SESSION['gb'][1]);
    $_3gb = strtolower($_SESSION['gb'][2]);
    $_4gb = strtolower($_SESSION['gb'][3]);

    $aa = $_SESSION[$_1ga];
    $bb = $_SESSION[$_2ga];
    $cc = $_SESSION[$_3ga];
    $dd = $_SESSION[$_4ga];

    $tabGroupA = [
        0 => $aa,
        1 => $bb,
        2 => $cc,
        3 => $dd
    ];

    $tabGroupB = [
        0 => $_SESSION[$_1gb],
        1 => $_SESSION[$_2gb],
        2 => $_SESSION[$_3gb],
        3 => $_SESSION[$_4gb]
    ];

    for ($i = 0; $i < 4; $i++) {
        for ($j = $i + 1; $j < 4; $j++) {
            if ($tabGroupA[$i][8] < $tabGroupA[$j][8]) {
                $temp = $tabGroupA[$i];
                $tabGroupA[$i] = $tabGroupA[$j];
                $tabGroupA[$j] = $temp;
            }
            if ($tabGroupA[$i][8] == $tabGroupA[$j][8]) {
                if ($tabGroupA[$i][7] < $tabGroupA[$j][7]) {
                    $temp = $tabGroupA[$i];
                    $tabGroupA[$i] = $tabGroupA[$j];
                    $tabGroupA[$j] = $temp;
                }
            }
        }
    }

    for ($i = 0; $i < 4; $i++) {
        for ($j = $i + 1; $j < 4; $j++) {
            if ($tabGroupB[$i][8] < $tabGroupB[$j][8]) {
                $temp = $tabGroupB[$i];
                $tabGroupB[$i] = $tabGroupB[$j];
                $tabGroupB[$j] = $temp;
            }
            if ($tabGroupB[$i][8] == $tabGroupB[$j][8]) {
                if ($tabGroupB[$i][7] < $tabGroupB[$j][7]) {
                    $temp = $tabGroupB[$i];
                    $tabGroupB[$i] = $tabGroupB[$j];
                    $tabGroupB[$j] = $temp;
                }
            }
        }
    }

    echo $tabGroupA[0][0] . " " . $tabGroupA[0][7] . " " . $tabGroupA[0][8] . "<br>";
    echo $tabGroupA[1][0] . " " . $tabGroupA[1][7] . " " . $tabGroupA[1][8] . "<br>";
    echo $tabGroupA[2][0] . " " . $tabGroupA[2][7] . " " . $tabGroupA[2][8] . "<br>";
    echo $tabGroupA[3][0] . " " . $tabGroupA[3][7] . " " . $tabGroupA[3][8] . "<br>";

    echo "<br><br>";

    echo $tabGroupB[0][0] . " " . $tabGroupB[0][7] . " " . $tabGroupB[0][8] . "<br>";
    echo $tabGroupB[1][0] . " " . $tabGroupB[1][7] . " " . $tabGroupB[1][8] . "<br>";
    echo $tabGroupB[2][0] . " " . $tabGroupB[2][7] . " " . $tabGroupB[2][8] . "<br>";
    echo $tabGroupB[3][0] . " " . $tabGroupB[3][7] . " " . $tabGroupB[3][8] . "<br>";


    if (count($matchPlayed) == 6) {
        $_ga1Qualif = $tabGroupA[0];
        $_ga2Qualif = $tabGroupA[1];

        echo $_ga1Qualif . "<br>";
        echo $_ga2Qualif . "<br>";
    }

    $_SESSION['groupe1A'] = $tabGroupA[0];
    $_SESSION['groupe2A'] = $tabGroupA[1];
    $_SESSION['groupe3A'] = $tabGroupA[2];
    $_SESSION['groupe4A'] = $tabGroupA[3];

    $_SESSION['groupe1B'] = $tabGroupB[0];
    $_SESSION['groupe2B'] = $tabGroupB[1];
    $_SESSION['groupe3B'] = $tabGroupB[2];
    $_SESSION['groupe4B'] = $tabGroupB[3];

    header('Location:dashbo.php?#resultMatch');
}
